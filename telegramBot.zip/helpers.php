<?php
function message($core)
{

    $chatId = $core->getUserChatId();
    $messageText = $core->getMessageText();

    $core->isTyping($chatId)->send();
    $core->sendMessage($chatId, $messageText)->replyToMessageId($core->messageId)->InlineKeyboardMarkup(
        [
            [['text' => 'salam', 'callback_data' => '1']],
            [['text' => 'salam2', 'callback_data' => '2']],
        ]
    )->send();
    exit();
}

function callback($core)
{
    if ($core->callbackObject->data == 1) {
        $core->sendMessage($core->callbackObject->message['chat']['id'], 'you click 1 data')->send();
        exit();
    } else {
        $core->answerCallbackQuery($core->content['callback_query']['id'])->text('you click two data')->send();
        $core->editMessageText($core->callbackObject->message['chat']['id'], $core->callbackMessageId)->text('message is edited')->InlineKeyboardMarkup(
            [
                [['text' => 'edited', 'callback_data' => '1']],
                [['text' => 'edited2', 'callback_data' => '2']],
            ]
        )->send();
        exit();

    }
    
}

function inlineQuery($core)
{
    $core->sendMessage($core->inlineMessageChatId, $core->inlineMessageObject)->send();
    exit();
}
