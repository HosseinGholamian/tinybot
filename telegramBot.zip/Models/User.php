<?php

namespace Models;

use Tinybot\Database\ORM\Model;
use Tinybot\Database\Traits\HasSoftDelete;

class User extends Model
{
    protected $table = "users";
    protected $fillable = ['firstname','username','user_chat_id','user_is_bot','is_admin' ,'status','chat_id'];
}
