<?php
namespace MainCommands;


use Models\User;
 
class MainCommand{
    public static function adduser($chatID , $firstname , $username ,$isBot){
        $inputs['firstname'] = $firstname;
        $inputs['username'] = $username;
        $inputs['user_chat_id'] = $chatID;
        $inputs['user_id_bot'] = $isBot ;
        $result = User::store($inputs);
        $result ? : exit();
    }

    public static function start_command( object $core){
        if($core->getMessageText() == "/start"){
            $core->sendMessage($core->userChatId,'here')->send();
            self::adduser($core->userChatId,$core->userFirstName,$core->username,$core->userIsBot);
            return true;
        }
        exit();
    }



}