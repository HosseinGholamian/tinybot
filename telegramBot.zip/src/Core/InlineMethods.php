<?php
namespace Tinybot\Core;

trait InlineMethods
{
    protected $method;
    protected $parameters = [];

    protected $allowableMethods = [
        'sendMessage' => [
            'disableWebPagePreview',
            'disableNotification',
            'protectContent',
            'replyToMessageId',
            'allowSendingWithoutReply',
            'parseMode',
            'ReplyKeyboardMarkup',
            'InlineKeyboardMarkup',
            'ReplyKeyboardRemove',
            'ForceReply',
        ],
    ];




}