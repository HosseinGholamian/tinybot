<?php

return [

    'DBHOST'     => 'localhost',
    'DBPASSWORD' => '0~9IzwZg4fjk',
    'DBUSERNAME' => 'hosseing_h031n',
    'DBNAME'     => 'hosseing_telegramBot'

];
