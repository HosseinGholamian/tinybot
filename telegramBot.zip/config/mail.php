<?php

return [
    'SMTP' => [
        'Host'       => 'smtp.gmail.com',
        'SMTPAuth'   => true,
        'Username'   => 'gholamianhossein96@gmail.com',
        'Password'   => 'admin@0024117536',
        'Port'       => 587,
        'setFrom'    => [
            'mail'  =>  'amlak@amlak.com',
            'name'  =>  'املاک'
        ]
    ]
];

