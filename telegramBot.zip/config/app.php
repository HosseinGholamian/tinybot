<?php

return [
    'APP_TITLE' => 'ربات تلگرام',
    'BASE_URL'  => 'http://localhost:8000',
    'BASE_DIR'  =>  dirname(__DIR__),
    'TOKEN'     => '5380414572:AAHbhs_Z5f1jFn8hreJRVq0SfsBArykzSus',
    'API_URL'   =>  'https://api.telegram.org/bot'
];
